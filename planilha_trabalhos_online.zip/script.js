const SUPABASE_URL="https://rehodfyczsqzfvtbyqur.supabase.co";
const SUPABASE_KEY="sb_publishable_G7pnXqh4fz-4RYVUgL8xyQ_L1fMfMP0";
const sb=supabase.createClient(SUPABASE_URL,SUPABASE_KEY);
let works=[], expenses=[], isSignup=false;
const $=s=>document.querySelector(s), $$=s=>document.querySelectorAll(s);
const money=v=>Number(v||0).toLocaleString('pt-BR',{style:'currency',currency:'BRL'});
const todayISO=()=>{let d=new Date();d.setMinutes(d.getMinutes()-d.getTimezoneOffset());return d.toISOString().slice(0,10)};
function weekStart(date){let d=new Date(date+'T12:00:00'),day=d.getDay(),diff=day===0?-6:1-day;d.setDate(d.getDate()+diff);return d}
function inWeek(date,ref){let s=weekStart(ref),e=new Date(s);e.setDate(e.getDate()+7);let d=new Date(date+'T12:00:00');return d>=s&&d<e}
function formatDate(d){return new Date(d+'T12:00:00').toLocaleDateString('pt-BR')}
function showToast(t){let x=$('#toast');x.textContent=t;x.classList.add('show');setTimeout(()=>x.classList.remove('show'),2200)}
function esc(s){return String(s).replace(/[&<>"']/g,m=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;'}[m]))}

async function loadData(){
 const {data:{user}}=await sb.auth.getUser(); if(!user)return;
 const [w,e]=await Promise.all([
   sb.from('works').select('*').order('work_date',{ascending:false}),
   sb.from('expenses').select('*').order('expense_date',{ascending:false})
 ]);
 if(w.error||e.error){showToast('Erro ao carregar dados.');return}
 works=(w.data||[]).map(x=>({id:x.id,date:x.work_date,name:x.name,qty:x.quantity,value:Number(x.unit_value)}));
 expenses=(e.data||[]).map(x=>({id:x.id,date:x.expense_date,name:x.name,category:x.category,value:Number(x.value)}));
 renderAll();
}
async function startApp(){
 $('#authScreen').style.display='none';$('#appShell').style.display='flex';
 let {data:{user}}=await sb.auth.getUser();
 if(user){let header=$('header');let div=document.createElement('div');div.className='userbar';div.innerHTML=`${esc(user.email)} <button class="logout" id="logout">Sair</button>`;header.appendChild(div);$('#logout').onclick=async()=>{await sb.auth.signOut();location.reload()};}
 $('#today').textContent=new Date().toLocaleDateString('pt-BR',{weekday:'long',day:'2-digit',month:'long',year:'numeric'});
 $('#weekDate').value=todayISO(); await loadData();
}
$('#authToggle').onclick=()=>{isSignup=!isSignup;$('#authTitle').textContent=isSignup?'Criar sua conta':'Entrar na sua conta';$('#authSubtitle').textContent=isSignup?'Crie uma conta para sincronizar seus dados.':'Acesse seus trabalhos e despesas de qualquer dispositivo.';$('#authSubmit').textContent=isSignup?'Criar conta':'Entrar';$('#authToggle').textContent=isSignup?'Já tenho uma conta':'Ainda não tenho uma conta';$('#authMessage').textContent=''};
$('#authForm').onsubmit=async e=>{e.preventDefault();let email=$('#authEmail').value.trim(),password=$('#authPassword').value;$('#authSubmit').disabled=true;let r=isSignup?await sb.auth.signUp({email,password}):await sb.auth.signInWithPassword({email,password});$('#authSubmit').disabled=false;if(r.error){$('#authMessage').textContent=r.error.message;$('#authMessage').className='auth-msg'}else if(isSignup&&!r.data.session){$('#authMessage').textContent='Conta criada! Verifique seu e-mail para confirmar.';$('#authMessage').className='auth-msg'}else startApp()};
sb.auth.getSession().then(({data})=>{if(data.session)startApp();else{$('#appShell').style.display='none';$('#authScreen').style.display='flex'}});

function go(section){$$('.section').forEach(x=>x.classList.toggle('active',x.id===section));$$('.nav-btn').forEach(x=>x.classList.toggle('active',x.dataset.section===section));$('#page-title').textContent=section==='dashboard'?'Dashboard':section[0].toUpperCase()+section.slice(1)}
$$('.nav-btn').forEach(b=>b.onclick=()=>go(b.dataset.section));$$('[data-section-link]').forEach(b=>b.onclick=()=>go(b.dataset.sectionLink));
$('#currentWeek').onclick=()=>{$('#weekDate').value=todayISO();renderDashboard()};
function renderDashboard(){let ref=$('#weekDate').value||todayISO(),ws=works.filter(w=>inWeek(w.date,ref)),es=expenses.filter(e=>inWeek(e.date,ref)),gross=ws.reduce((a,w)=>a+w.qty*w.value,0),exp=es.reduce((a,e)=>a+e.value,0),qty=ws.reduce((a,w)=>a+w.qty,0);$('#gross').textContent=money(gross);$('#expensesTotal').textContent=money(exp);$('#net').textContent=money(gross-exp);$('#workCount').textContent=ws.length;$('#quantityCount').textContent=qty;let names=['Segunda','Terça','Quarta','Quinta','Sexta','Sábado','Domingo'],totals=names.map((_,i)=>{let d=new Date(weekStart(ref));d.setDate(d.getDate()+i);let iso=d.toISOString().slice(0,10);return ws.filter(w=>w.date===iso).reduce((a,w)=>a+w.qty*w.value,0)}),max=Math.max(...totals,1);$('#days').innerHTML=names.map((n,i)=>`<div class="day"><span>${n}</span><div class="bar"><i style="width:${totals[i]/max*100}%"></i></div><b>${money(totals[i])}</b></div>`).join('');let recent=works.slice(0,5);$('#recentList').innerHTML=recent.length?recent.map(w=>`<div class="list-item"><div><b>${esc(w.name)}</b><small>${formatDate(w.date)} · ${w.qty} un.</small></div><strong>${money(w.qty*w.value)}</strong></div>`).join(''):'<div class="empty">Nenhum lançamento ainda.</div>'}
function renderWorks(){let q=$('#searchWork').value.toLowerCase(),date=$('#workDateFilter').value,rows=works.filter(w=>(!q||w.name.toLowerCase().includes(q))&&(!date||w.date===date));$('#workTable').innerHTML=rows.map(w=>`<tr><td>${formatDate(w.date)}</td><td><b>${esc(w.name)}</b></td><td>${w.qty}</td><td>${money(w.value)}</td><td class="total">${money(w.qty*w.value)}</td><td class="actions"><button onclick="editWork('${w.id}')">✎</button><button onclick="deleteWork('${w.id}')">🗑</button></td></tr>`).join('');$('#emptyWorks').style.display=rows.length?'none':'block'}
function renderExpenses(){let q=$('#searchExpense').value.toLowerCase(),date=$('#expenseDateFilter').value,rows=expenses.filter(e=>(!q||e.name.toLowerCase().includes(q)||e.category.toLowerCase().includes(q))&&(!date||e.date===date));$('#expenseTable').innerHTML=rows.map(e=>`<tr><td>${formatDate(e.date)}</td><td><b>${esc(e.name)}</b></td><td>${esc(e.category)}</td><td class="total">${money(e.value)}</td><td class="actions"><button onclick="editExpense('${e.id}')">✎</button><button onclick="deleteExpense('${e.id}')">🗑</button></td></tr>`).join('');$('#emptyExpenses').style.display=rows.length?'none':'block';$('#expensePageTotal').textContent=money(expenses.reduce((a,e)=>a+e.value,0)}
function renderAll(){renderDashboard();renderWorks();renderExpenses()}
function openWork(w=null){$('#workModal').classList.add('open');$('#workModalTitle').textContent=w?'Editar trabalho':'Novo trabalho';$('#workId').value=w?.id||'';$('#workDate').value=w?.date||todayISO();$('#workName').value=w?.name||'';$('#workQty').value=w?.qty||1;$('#workValue').value=w?.value??'';preview()}
function openExpense(e=null){$('#expenseModal').classList.add('open');$('#expenseModalTitle').textContent=e?'Editar despesa':'Nova despesa';$('#expenseId').value=e?.id||'';$('#expenseDate').value=e?.date||todayISO();$('#expenseName').value=e?.name||'';$('#expenseCategory').value=e?.category||'Material';$('#expenseValue').value=e?.value??''}
function closeModal(id){$('#'+id).classList.remove('open')} $$('[data-close]').forEach(b=>b.onclick=()=>closeModal(b.dataset.close));
$('#addWork').onclick=()=>openWork();$('#addWorkTop').onclick=()=>openWork();$('#addExpense').onclick=()=>openExpense();$('#workQty').oninput=preview;$('#workValue').oninput=preview;function preview(){$('#workPreview').textContent=money((+$('#workQty').value||0)*(+$('#workValue').value||0))}
$('#workForm').onsubmit=async e=>{e.preventDefault();let id=$('#workId').value,obj={date:$('#workDate').value,name:$('#workName').value.trim(),qty:+$('#workQty').value,value:+$('#workValue').value};let r=id?await sb.from('works').update({work_date:obj.date,name:obj.name,quantity:obj.qty,unit_value:obj.value}).eq('id',id):await sb.from('works').insert({work_date:obj.date,name:obj.name,quantity:obj.qty,unit_value:obj.value});if(r.error)showToast(r.error.message);else{closeModal('workModal');await loadData();showToast('Trabalho salvo!')}}
$('#expenseForm').onsubmit=async e=>{e.preventDefault();let id=$('#expenseId').value,obj={date:$('#expenseDate').value,name:$('#expenseName').value.trim(),category:$('#expenseCategory').value,value:+$('#expenseValue').value};let r=id?await sb.from('expenses').update({expense_date:obj.date,name:obj.name,category:obj.category,value:obj.value}).eq('id',id):await sb.from('expenses').insert({expense_date:obj.date,name:obj.name,category:obj.category,value:obj.value});if(r.error)showToast(r.error.message);else{closeModal('expenseModal');await loadData();showToast('Despesa salva!')}}
window.editWork=id=>openWork(works.find(x=>x.id===id));window.editExpense=id=>openExpense(expenses.find(x=>x.id===id));
window.deleteWork=async id=>{if(confirm('Excluir este trabalho?')){let r=await sb.from('works').delete().eq('id',id);if(r.error)showToast(r.error.message);else{await loadData();showToast('Trabalho excluído.')}}};window.deleteExpense=async id=>{if(confirm('Excluir esta despesa?')){let r=await sb.from('expenses').delete().eq('id',id);if(r.error)showToast(r.error.message);else{await loadData();showToast('Despesa excluída.')}}};
['weekDate','searchWork','workDateFilter','searchExpense','expenseDateFilter'].forEach(id=>$('#'+id).oninput=()=>id==='weekDate'?renderDashboard():id==='searchWork'||id==='workDateFilter'?renderWorks():renderExpenses());
